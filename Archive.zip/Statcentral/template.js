$(document).ready(function () {

    //$('body').on('click', '#society', function () {
    //    $('.sub-theme-container').load('entity/society/', 'html').hide().fadeIn("slow");
    //    $('.theme-box').removeClass('active');
    //    $('#society').addClass('active');
    //});

    //$('body').on('click', '#economy', function () {
    //    $('.sub-theme-container').load('entity/economy/', 'html').hide().fadeIn("slow");
    //    $('.theme-box').removeClass('active');
    //    $('#economy').addClass('active');
    //});

    //$('body').on('click', '#business', function () {
    //    $('.sub-theme-container').load('entity/business/', 'html').hide().fadeIn("slow");
    //    $('.theme-box').removeClass('active');
    //    $('#business').addClass('active');
    //});

    //$('body').on('click', '#labour-market', function () {
    //    $('.sub-theme-container').load('entity/labour-market/', 'html').hide().fadeIn("slow");
    //    $('.theme-box').removeClass('active');
    //    $('#labour-market').addClass('active');
    //});

    //$('body').on('click', '#environment', function () {
    //    $('.sub-theme-container').load('entity/environment/', 'html').hide().fadeIn("slow");
    //    $('.theme-box').removeClass('active');
    //    $('#environment').addClass('active');
    //});

});