$(document).ready(function () {

    $("#modal, #modal-2").iziModal({
        icon: '.fa fa-times',
        width: 1000,
        overlayColor: 'rgba(0, 0, 0, 0.8)',
        top: 40,
        bottom: 40,
        transitionIn: 'fadeInUp',
        transitionOut: 'fadeOutDown',
        bodyOverflow: true,
        radius: 5
    });

    $('.themes li').click(function(){
        // corresponding class in experiments should activate hover 
        // for several seconds

        var className = $(this).find('span').attr('class');
        $('.experiments div.' + className).toggleClass('hover');
     
    });




    $('body').on('click', '.trigger-1', function (event) {
        event.preventDefault();
        $('#modal').iziModal('open');   
    });

    $('body').on('click', '.trigger-2', function (event) {
        event.preventDefault();
        $('#modal-2').iziModal('open');
    });

    //$('.item h3').hide();
    //$('.item').addClass('disable');
    $('.exit').on('click', function () {
        $('.warning').hide();
        //$('.item h3').show().fadeIn('slow');
        //$('.item').removeClass('disable');
    });

    $(".burger").on('click', function () {
        $(this).toggleClass("animate");
        //$('.logo').toggleClass("slide-out");
        $('.site-navigation ul').toggleClass("slide-in");
    });

});

