﻿$(document).ready(function () {

    $('#society').on('click', function () {
        $('.theme-box').removeClass('active');
        
        $('#society').addClass('active');
        $('.panel-society').toggleClass('open');
        $('.panel-business').removeClass('open');
        $('.panel-labour').removeClass('open');
        $('.panel-environment').removeClass('open');
        $('.panel-economy').removeClass('open');

    });

    $('#economy').on('click', function () {
        $('.theme-box').removeClass('active');
   
        $('#economy').addClass('active');
        $('.panel-economy').toggleClass('open');
        $('.panel-society').removeClass('open');
        $('.panel-business').removeClass('open');
        $('.panel-labour').removeClass('open');
        $('.panel-environment').removeClass('open');


    });

    $('#business').on('click', function () {
        $('.theme-box').removeClass('active');

        $('#business').addClass('active');
        $('.panel-business').toggleClass('open');
        $('.panel-society').removeClass('open');
        $('.panel-labour').removeClass('open');
        $('.panel-environment').removeClass('open');
        $('.panel-economy').removeClass('open');


    });

    $('#labour-market').on('click', function () {
        $('.theme-box').removeClass('active');
        $('#labour-market').addClass('active');

        $('.panel-labour').toggleClass('open');
        $('.panel-society').removeClass('open');
        $('.panel-environment').removeClass('open');
        $('.panel-economy').removeClass('open');
        $('.panel-business').removeClass('open');


    });

    $('#environment').on('click', function () {
        $('.theme-box').removeClass('active');
        $('#environment').addClass('active');
        $('.panel-environment').toggleClass('open');
        $('.panel-society').removeClass('open');
        $('.panel-economy').removeClass('open');
        $('.panel-business').removeClass('open');
        $('.panel-labour').removeClass('open');


    });

    $(".burger").on('click', function () {
        $(this).toggleClass("animate");
        $('.header').toggleClass("slide-out");
        $('.main-nav').toggleClass("slide-in");
    });


});